#!/bin/bash
# ===========================================================
# Script: backup_full.sh
# Autor: Matías/Iván (v1.0)
# Descripción:
#   Genera un backup comprimido (.tar.gz) de un directorio origen
#   en un directorio destino, validando la existencia de ambos.
# ===========================================================

# ---------- Función de ayuda ----------
mostrar_ayuda() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo
    echo "Este script genera un archivo .tar.gz con el formato:"
    echo "  nombreDir_bkp_YYYYMMDD.tar.gz"
    echo
    echo "Opciones:"
    echo "  -help        Muestra esta ayuda"
    exit 0
}

# ---------- Validación de parámetros ----------
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    mostrar_ayuda
fi

if [[ $# -ne 2 ]]; then
    echo "Error: se requieren 2 parámetros: <origen> <destino>"
    echo "Use -help para más información."
    exit 1
fi

origen="$1"
destino="$2"

# ---------- Validar existencia de directorios ----------
if [[ ! -d "$origen" ]]; then
    echo "Error: el directorio de origen '$origen' no existe."
    exit 2
fi

if [[ ! -d "$destino" ]]; then
    echo "Error: el directorio de destino '$destino' no existe."
    exit 3
fi

# ---------- Preparar variables ----------
nombre_dir=$(basename "$origen")
fecha=$(date +%Y%m%d)
archivo="${nombre_dir}_bkp_${fecha}.tar.gz"
ruta_salida="${destino}/${archivo}"

# ---------- Crear backup ----------
echo "Creando backup de '$origen'..."
tar -czf "$ruta_salida" -C "$(dirname "$origen")" "$nombre_dir"

# ---------- Verificar resultado ----------
if [[ $? -eq 0 ]]; then
    echo "Backup creado exitosamente: $ruta_salida"
else
    echo "Error: no se pudo crear el backup."
    exit 4
fi
